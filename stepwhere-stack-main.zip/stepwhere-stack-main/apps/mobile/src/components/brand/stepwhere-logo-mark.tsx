import React, { useId, useMemo } from 'react';
import Svg, { Defs, G, LinearGradient, Path, Stop } from 'react-native-svg';

const VIEWBOX_WIDTH = 670.24;
const VIEWBOX_HEIGHT = 84;
const DEFAULT_HEIGHT = 22;
const ASPECT_RATIO = VIEWBOX_WIDTH / VIEWBOX_HEIGHT;

type StepwhereLogoMarkProps = {
  colors: {
    emblemDark: string;
    emblemGradientEnd: string;
    emblemGradientStart: string;
    step: string;
    whereGradientEnd: string;
    whereGradientStart: string;
  };
  height?: number;
  width?: number;
};

export function StepwhereLogoMark({
  colors,
  height = DEFAULT_HEIGHT,
  width,
}: StepwhereLogoMarkProps) {
  const gradientBaseId = useId().replace(/:/g, '-');
  const gradientIds = useMemo(() => ({
    emblemPrimary: `stepwhere-logo-emblem-primary-${gradientBaseId}`,
    emblemSecondary: `stepwhere-logo-emblem-secondary-${gradientBaseId}`,
    where: `stepwhere-logo-where-${gradientBaseId}`,
  }), [gradientBaseId]);
  const resolvedWidth = width ?? height * ASPECT_RATIO;

  return (
    <Svg
      height={height}
      preserveAspectRatio="xMinYMid meet"
      viewBox={`0 0 ${VIEWBOX_WIDTH} ${VIEWBOX_HEIGHT}`}
      width={resolvedWidth}>
      <Defs>
        <LinearGradient id={gradientIds.where} x1="273.74" x2="670.24" y1="43.63" y2="43.63" gradientUnits="userSpaceOnUse">
          <Stop offset="0" stopColor={colors.whereGradientStart} />
          <Stop offset="1" stopColor={colors.whereGradientEnd} />
        </LinearGradient>
        <LinearGradient
          id={gradientIds.emblemPrimary}
          x1="3"
          x2="55.51"
          y1="2107.61"
          y2="2107.61"
          gradientTransform="translate(0 -2034)"
          gradientUnits="userSpaceOnUse">
          <Stop offset="0" stopColor={colors.emblemGradientStart} />
          <Stop offset="1" stopColor={colors.emblemGradientEnd} />
        </LinearGradient>
        <LinearGradient
          id={gradientIds.emblemSecondary}
          x1=".86"
          x2="62.8"
          y1="2071.19"
          y2="2071.19"
          gradientTransform="translate(0 -2034)"
          gradientUnits="userSpaceOnUse">
          <Stop offset="0" stopColor={colors.emblemGradientStart} />
          <Stop offset="1" stopColor={colors.emblemGradientEnd} />
        </LinearGradient>
      </Defs>
      <G>
        <G>
          <Path fill={colors.step} d="M94.04,78.63V21.83h-22.4v-13.2h61v13.2h-22.4v56.8h-16.2Z" />
          <Path fill={colors.step} d="M208.44,78.63V8.63h30.3c6.27,0,11.67,1.02,16.2,3.05,4.53,2.03,8.03,4.95,10.5,8.75,2.47,3.8,3.7,8.33,3.7,13.6s-1.23,9.7-3.7,13.5c-2.47,3.8-5.97,6.72-10.5,8.75-4.53,2.03-9.93,3.05-16.2,3.05h-21.3l7.2-7.3v26.6h-16.2ZM224.64,53.83l-7.2-7.7h20.4c5,0,8.73-1.07,11.2-3.2,2.47-2.13,3.7-5.1,3.7-8.9s-1.23-6.87-3.7-9c-2.47-2.13-6.2-3.2-11.2-3.2h-20.4l7.2-7.7v39.7Z" />
          <Path fill={colors.step} d="M141.34,78.63V8.63h52.9v13h-36.8v44h38.1v13h-54.2ZM156.24,49.43v-12.6h33.7v12.6h-33.7Z" />
        </G>
        <G>
          <Path fill={`url(#${gradientIds.where})`} d="M296.64,78.63l-22.9-70h16.8l19.9,62h-8.4l20.8-62h15l20,62h-8.1l20.4-62h15.5l-22.9,70h-17.4l-17.7-54.4h4.6l-18.2,54.4h-17.4ZM394.64,78.63V8.63h16.2v70h-16.2ZM409.64,49.93v-13.7h34.2v13.7h-34.2ZM442.64,78.63V8.63h16.2v70h-16.2ZM475.44,78.63V8.63h52.9v13h-36.8v44h38.1v13h-54.2ZM490.34,49.43v-12.6h33.7v12.6h-33.7ZM542.54,78.63V8.63h29.9c9.73,0,17.3,2.25,22.7,6.75,5.4,4.5,8.1,10.72,8.1,18.65,0,5.2-1.23,9.68-3.7,13.45-2.47,3.77-5.97,6.65-10.5,8.65-4.53,2-9.93,3-16.2,3h-21.3l7.2-7.1v26.6h-16.2ZM558.74,53.83l-7.2-7.6h20.4c5,0,8.73-1.08,11.2-3.25,2.47-2.17,3.7-5.15,3.7-8.95s-1.23-6.87-3.7-9c-2.47-2.13-6.2-3.2-11.2-3.2h-20.4l7.2-7.7v39.7ZM587.04,78.63l-17.5-25.4h17.3l17.7,25.4h-17.5ZM616.04,78.63V8.63h52.9v13h-36.8v44h38.1v13h-54.2ZM630.94,49.43v-12.6h33.7v12.6h-33.7Z" />
        </G>
        <G>
          <Path fill={`url(#${gradientIds.emblemPrimary})`} d="M8.45,63.24c15.32,6.07,30.24,12.18,47.05,12.34-2,1.31-3.86,2.92-6.02,3.88-15.44,6.85-30.48,6.02-44.96-2.82-1.86-1.14-1.85-1.34-.88-3.34,1.67-3.45,3.31-6.91,4.8-10.04h0Z" />
          <Path fill={colors.emblemDark} d="M6.75,60.15c15.01,6.79,29.62,13.62,46.41,14.58-2.06,1.21-4,2.73-6.2,3.58-15.76,6.1-30.73,4.55-44.77-4.98-1.81-1.23-1.78-1.42-.72-3.38,1.83-3.36,3.63-6.74,5.28-9.8h0Z" />
          <Path fill={`url(#${gradientIds.emblemSecondary})`} d="M51.31,24.09c-2.74-1.48-5.27-3.14-8.02-4.27-5.57-2.29-11.37-3.16-17.31-1.51-1.1.3-2.19.85-3.12,1.52-3.04,2.19-3.35,6.11-.38,8.4,1.98,1.52,4.38,2.63,6.75,3.48,5.33,1.92,10.86,3.32,16.12,5.4,5.82,2.29,10.9,5.77,14.38,11.22,4.26,6.67,4.12,16.66-.49,23.05-.17.24-.57.76-1.07,1.12-.28-3.63-3.24-4.37-5.49-6.04-3.37-2.51-6.37-5.52-9.41-8.45-1.76-1.7-3.42-3.54-4.86-5.51-1.03-1.39-1.71-3.06-2.38-4.68-.46-1.1-.66-2.31-2.12-2.45-1.33-.12-3.65,1.32-3.79,2.5-.13,1.15-.73,1.59-1.69,1.97-3.64,1.43-6.76-.15-7.68-3.94-.53-2.21-1.96-2.9-4-1.94-.4.19-.87.33-1.17.64-2.06,2.06-2.23,1.42-4.59-.02-3.89-2.37-7.02-5.46-8.68-9.82-1.99-5.24-1.84-10.54.02-15.72C5.68,9.7,12.88,4.91,22.22,2.9c8.2-1.77,16.3-1.13,24.25,1.36,4.37,1.37,8.38,3.57,12.1,6.25.7.51,1.09,1.13.53,1.99-2.39,3.69-4.78,7.38-7.19,11.06-.17.26-.5.43-.61.53h0Z" />
          <Path fill={colors.emblemDark} d="M50.4,21.92c-2.76-1.44-5.31-3.06-8.08-4.15-5.6-2.21-11.41-3-17.33-1.27-1.1.32-2.18.88-3.1,1.57-3.01,2.23-3.26,6.16-.27,8.4,2,1.5,4.41,2.56,6.8,3.39,5.36,1.85,10.9,3.17,16.2,5.17,5.85,2.21,10.98,5.61,14.53,11.01,4.35,6.61,4.3,16.75-.22,23.2-.17.24-.51.62-1,.99-.33-3.63-3.31-4.33-5.57-5.97-3.4-2.46-6.45-5.43-9.52-8.32-1.78-1.67-3.47-3.49-4.94-5.44-1.04-1.38-1.75-3.04-2.44-4.64-.47-1.09-.69-2.3-2.16-2.42-1.33-.11-3.63,1.37-3.75,2.55-.11,1.15-.71,1.6-1.66,1.99-3.62,1.48-6.77-.05-7.74-3.83-.57-2.2-2-2.87-4.03-1.88-.4.2-.86.35-1.16.65-2.02,2.09-2.21,1.45-4.59.05-3.93-2.31-7.09-5.36-8.81-9.7-2.07-5.21-1.99-10.52-.2-15.71C4.57,8.18,11.71,3.29,21.02,1.14c8.17-1.89,16.28-1.36,24.26,1.02,4.39,1.31,8.43,3.45,12.19,6.08.71.5,1.11,1.11.56,1.98-2.34,3.72-4.68,7.44-7.03,11.16-.17.27-.49.43-.61.53h0Z" />
        </G>
      </G>
    </Svg>
  );
}

export type { StepwhereLogoMarkProps };
